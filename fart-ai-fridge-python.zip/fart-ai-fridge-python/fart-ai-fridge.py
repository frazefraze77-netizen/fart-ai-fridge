"""FART AI manual food entry.

Asks for the four fields the app needs (name, company or brand, weight in
grams, and expiry date), stores each item as a dictionary in a list, and
prints the inventory. Uses only the Python standard library.
"""
from datetime import date

inventory = []


def ask_number(prompt):
    """Ask until the user enters a number greater than 0."""
    while True:
        try:
            value = float(input(prompt).strip())
            if value > 0:
                return value
        except ValueError:
            pass
        print("Please enter a number greater than 0.")


def ask_date(prompt):
    """Ask until the user enters a real date in YYYY-MM-DD format."""
    while True:
        text = input(prompt).strip()
        try:
            date.fromisoformat(text)
            return text
        except ValueError:
            print("Please use the format YYYY-MM-DD, for example 2026-11-20.")


def main():
    print("FART AI manual entry. Press Enter on the food name to finish.\n")
    while True:
        name = input("Food name (Enter to finish): ").strip()
        if not name:
            break
        company = input("Company or brand: ").strip()
        quantity_g = ask_number("Weight in grams: ")
        expiration_date = ask_date("Date (YYYY-MM-DD): ")

        inventory.append({
            "name": name,
            "company": company,
            "quantity_g": quantity_g,
            "expiration_date": expiration_date,
        })
        print(f"Added {name}.\n")

    print("Inventory:")
    for item in inventory:
        print(item)


if __name__ == "__main__":
    main()
