# FART AI fridge: Python files

- `fart-ai-fridge.py`: manual food entry. Asks for name, company or brand, weight in grams and date, then prints the list.
- `fart-ai-fridge-features.py`: main features (priority scores, expiry estimates, take-out with macros and recipe, shopping list, recurring foods, 30-day review).
- `fart_catalog.json`: food data exported from the website's catalogue. Keep it in the same folder as `fart-ai-fridge-features.py`.

Requires Python 3.9 or later. Uses only the standard library.

Run:

    python fart-ai-fridge.py
    python fart-ai-fridge-features.py

The features file saves its data to `fridge_state.json` in the same folder.
