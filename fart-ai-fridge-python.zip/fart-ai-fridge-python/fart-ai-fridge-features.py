"""FART AI fridge: Python version of the app's main features.

Mirrors the rules in the browser app (public/core.js):
  - add food with a label date, or an estimate from the catalogue storage guide
  - priority score (0-100, lower = use sooner) and expiry status
  - take out a food, which records usage, macros for the amount taken, and a shopping item
  - shopping list from foods taken out and frequent foods that are missing
  - recurring foods (2+ take-outs in the last 30 days)
  - 30-day review that clears old and infrequent usage

Needs only the Python standard library. Keep fart_catalog.json in the same
folder as this file. State is saved to fridge_state.json.
"""
import json
import math
import os
import sys
import unicodedata
from datetime import date, datetime, timedelta

try:
    from zoneinfo import ZoneInfo
    BERLIN = ZoneInfo("Europe/Berlin")
except Exception:  # tzdata missing on some Windows installs
    BERLIN = None

HERE = os.path.dirname(os.path.abspath(__file__))
CATALOG_FILE = os.path.join(HERE, "fart_catalog.json")
STATE_FILE = os.path.join(HERE, "fridge_state.json")
WINDOW = 30      # days of usage history kept
FREQUENT = 2     # take-outs needed to count as a recurring food

with open(CATALOG_FILE, encoding="utf-8") as f:
    CATALOG = json.load(f)
FOODS = CATALOG["foods"]
ALIASES = CATALOG["aliases"]


# ---------- dates and names ----------

def today():
    """Today's date in Berlin, to match the browser app."""
    now = datetime.now(BERLIN) if BERLIN else datetime.now()
    return now.date().isoformat()


def days_between(a, b):
    """Days from b to a (a - b), as ISO date strings."""
    return (date.fromisoformat(a) - date.fromisoformat(b)).days


def add_days(iso, count):
    return (date.fromisoformat(iso) + timedelta(days=count)).isoformat()


def valid_date(text):
    try:
        date.fromisoformat(text)
        return True
    except (TypeError, ValueError):
        return False


def normalize(name):
    text = unicodedata.normalize("NFKD", str(name or "").strip().lower())
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = text.replace("ß", "ss")
    out = []
    for ch in text:
        out.append(ch if ch.isalnum() else " ")
    return " ".join("".join(out).split())


def key_for(name):
    key = normalize(name) or str(name or "").strip().lower()
    return ALIASES.get(key, key)


def catalog_for(name):
    return FOODS.get(key_for(name))


# ---------- state ----------

def new_state(current_date=None):
    current_date = current_date or today()
    return {
        "date": current_date,
        "foods": [],
        "history": [],
        "to_buy": [],
        "last_take_out": None,
        "preference": "any",
        "nutrition_goal": "fiber",
        "next_review": add_days(current_date, WINDOW),
    }


def load_state(path=STATE_FILE):
    if not os.path.exists(path):
        return new_state()
    with open(path, encoding="utf-8") as f:
        state = json.load(f)
    state["date"] = today()  # the fridge always works from the real date
    return state


def save_state(state, path=STATE_FILE):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)


# ---------- food model ----------

def make_food(name, company, grams, expiration_date, state):
    """Create a food record. Uses the catalogue storage guide if no date is given."""
    profile = catalog_for(name)
    display_name = profile["name"] if profile else name.strip()
    stored = state["date"]
    provided = valid_date(expiration_date)
    days = profile.get("storage_days") if profile else None
    if provided:
        expiry, source = expiration_date, "label"
    elif days:
        expiry, source = add_days(stored, days), "estimate"
    else:
        expiry, source = None, "unknown"
    return {
        "id": f"food-{datetime.now().timestamp():.6f}",
        "name": display_name,
        "company": company.strip() or "Unbranded",
        "quantity_g": grams,
        "stored_since": stored,
        "expiration_date": expiry,
        "date_source": source,
    }


def days_left(food, current_date):
    """Days until the food's date, or None if no date is known."""
    if not valid_date(food.get("expiration_date")):
        return None
    return days_between(food["expiration_date"], current_date)


def date_label(food, current_date):
    days = days_left(food, current_date)
    if days is None:
        return "Date needed"
    if days < 0:
        return "Estimate passed" if food["date_source"] == "estimate" else "Past date"
    if days == 0:
        return "Due today"
    if days == 1:
        return "Due tomorrow"
    return f"In {days} days"


def score_food(food, state):
    """Priority score 0-100 and its components, as in core.js scoreFood()."""
    current = state["date"]
    days = days_left(food, current)
    profile = catalog_for(food["name"])
    goal = state["nutrition_goal"]
    target = 10 if goal == "protein" else 5
    minutes = profile.get("recipe_minutes") if profile else None
    nutrient = (profile or {}).get("macros", {}).get(goal)

    expiry = 0 if days is None or days < 0 else max(0, 40 - 6 * days)
    if state["preference"] == "any":
        preference = 10
    elif profile and state["preference"] == profile.get("group"):
        preference = 20
    else:
        preference = 0
    nutrition = 20 * min(1, nutrient / target) if isinstance(nutrient, (int, float)) else 0
    if minutes is None:
        prep = 0
    elif minutes <= 10:
        prep = 20
    elif minutes <= 20:
        prep = 10
    else:
        prep = 0

    if days is not None and days < 0:
        points = None
        level = "Past date"
    else:
        # Round half up, like JavaScript's Math.round in the browser app.
        points = 100 - math.floor(expiry + preference + nutrition + prep + 0.5)
        level = "Low" if points <= 30 else "Good" if points <= 55 else "Very good"
    return {"points": points, "level": level, "expiry": expiry,
            "preference": preference, "nutrition": round(nutrition, 1), "prep": prep}


def ranked_foods(state):
    def sort_key(food):
        score = score_food(food, state)["points"]
        days = days_left(food, state["date"])
        return (score if score is not None else math.inf,
                days if days is not None else math.inf,
                food["name"])
    return sorted(state["foods"], key=sort_key)


def macros_for(food):
    profile = catalog_for(food["name"])
    if not profile or not profile.get("macros") or not food.get("quantity_g"):
        return None
    return {k: round(v * food["quantity_g"] / 100, 1) for k, v in profile["macros"].items()}


# ---------- usage, memory and shopping ----------

def active_uses(state):
    return [e for e in state["history"]
            if 0 <= days_between(state["date"], e["date"]) < WINDOW]


def recurring(state):
    groups = {}
    for entry in active_uses(state):
        key = key_for(entry["name"])
        if key not in groups:
            groups[key] = {**entry, "key": key, "uses": 1}
        else:
            prev = groups[key]
            latest = entry if entry["date"] >= prev["date"] else prev
            groups[key] = {**latest, "key": key, "uses": prev["uses"] + 1}
    return sorted(groups.values(),
                  key=lambda e: (-e["uses"], [-ord(c) for c in e["date"]], e["name"]))


def is_available(name, state):
    """True if the fridge has this food and it is not past its date."""
    for food in state["foods"]:
        if key_for(food["name"]) == key_for(name):
            days = days_left(food, state["date"])
            if days is None or days >= 0:
                return True
    return False


def shopping_list(state):
    rows = {}
    for item in state["to_buy"]:
        if not is_available(item["name"], state):
            rows[key_for(item["name"])] = {"name": item["name"], "reason": "taken out"}
    for item in recurring(state):
        if item["uses"] < FREQUENT or is_available(item["name"], state):
            continue
        rows.setdefault(item["key"], {"name": item["name"], "reason": "frequent"})
    return sorted(rows.values(), key=lambda r: r["name"])


def take_out(state, food_id):
    food = next((f for f in state["foods"] if f["id"] == food_id), None)
    if food is None:
        return None
    days = days_left(food, state["date"])
    if days is not None and days < 0:
        return None  # past-date foods cannot be taken out as normal
    state["foods"] = [f for f in state["foods"] if f["id"] != food_id]
    state["history"].append({**food, "date": state["date"]})
    if not any(key_for(i["name"]) == key_for(food["name"]) for i in state["to_buy"]):
        state["to_buy"].append({"name": food["name"]})
    state["last_take_out"] = {**food, "taken_on": state["date"]}
    return food


def advance_days(state, days):
    """Move the demo date forward. A 30-day review clears old and infrequent usage."""
    state["date"] = add_days(state["date"], days)
    if state["date"] < state["next_review"]:
        return False
    keep = {e["key"] for e in recurring(state) if e["uses"] >= FREQUENT}
    state["history"] = [e for e in active_uses(state) if key_for(e["name"]) in keep]
    while state["next_review"] <= state["date"]:
        state["next_review"] = add_days(state["next_review"], WINDOW)
    return True


# ---------- command line ----------

def ask(prompt):
    try:
        return input(prompt).strip()
    except EOFError:
        return ""


def ask_grams(prompt):
    while True:
        text = ask(prompt)
        try:
            value = float(text)
            if value >= 1:
                return value
        except ValueError:
            pass
        print("Enter a weight of at least 1 gram.")


def print_inventory(state):
    foods = ranked_foods(state)
    if not foods:
        print("Your fridge is empty.")
        return
    print(f"\nFridge on {state['date']} (lower score = use sooner):")
    for food in foods:
        s = score_food(food, state)
        score = "past" if s["points"] is None else str(s["points"])
        print(f"  {score:>4}  {s['level']:<10} {food['name']} ({food['company']}, "
              f"{food['quantity_g']:g} g) - {date_label(food, state['date'])}"
              f" [{food['date_source']}]")


def add_food(state):
    name = ask("Food name: ")
    if not name:
        print("Food name is needed.")
        return
    company = ask("Company or brand (optional): ")
    grams = ask_grams("Weight in grams: ")
    while True:
        text = ask("Expiry date YYYY-MM-DD (Enter to estimate from the storage guide): ")
        if not text or valid_date(text):
            break
        print("Use the format YYYY-MM-DD, for example 2026-11-20.")
    food = make_food(name, company, grams, text, state)
    state["foods"].append(food)
    state["to_buy"] = [i for i in state["to_buy"] if key_for(i["name"]) != key_for(food["name"])]
    print(f"Added {food['name']}. Expiry: {food['expiration_date'] or 'unknown, please set one'}"
          f" ({food['date_source']}).")


def take_out_menu(state):
    if not state["foods"]:
        print("Nothing to take out.")
        return
    print_inventory(state)
    choice = ask("Number to take out (1 = first in the list above, Enter to cancel): ")
    if not choice:
        return
    try:
        index = int(choice) - 1
        food = ranked_foods(state)[index]
    except (ValueError, IndexError):
        print("No such item.")
        return
    taken = take_out(state, food["id"])
    if taken is None:
        print("That food is past its date and cannot be taken out.")
        return
    print(f"\nTook out {taken['name']} ({taken['quantity_g']:g} g).")
    macros = macros_for(taken)
    if macros:
        print("Macros for this amount: " + ", ".join(f"{k} {v} g" for k, v in macros.items()))
    profile = catalog_for(taken["name"])
    if profile and profile.get("recipe_name"):
        extras = ", ".join(profile.get("recipe_extras", []))
        print(f"Suggested recipe: {profile['recipe_name']} ({profile['recipe_minutes']} min)"
              + (f" with {extras}" if extras else ""))
    print("Added to the shopping list.")


def show_shopping(state):
    rows = shopping_list(state)
    if not rows:
        print("Shopping list is empty.")
        return
    print("\nShopping list:")
    for row in rows:
        print(f"  - {row['name']} ({row['reason']})")


def show_recurring(state):
    rows = recurring(state)
    if not rows:
        print("No usage in the last 30 days.")
        return
    print("\nRecurring foods (last 30 days):")
    for row in rows:
        tag = "frequent" if row["uses"] >= FREQUENT else "one use"
        print(f"  {row['uses']} use(s)  {row['name']}  [{tag}]")


def settings_menu(state):
    pref = ask("Preference (any, fruit, vegetable, dairy, protein, pantry) [Enter = keep]: ")
    if pref:
        if pref in ("any", "fruit", "vegetable", "dairy", "protein", "pantry"):
            state["preference"] = pref
        else:
            print("Unknown preference; kept the old one.")
    goal = ask("Nutrition goal (fiber or protein) [Enter = keep]: ")
    if goal:
        if goal in ("fiber", "protein"):
            state["nutrition_goal"] = goal
        else:
            print("Unknown goal; kept the old one.")
    print(f"Preference: {state['preference']}, goal: {state['nutrition_goal']}")


def advance_menu(state):
    text = ask("Days to advance (e.g. 1 or 30): ")
    try:
        days = int(text)
    except ValueError:
        print("Enter a whole number of days.")
        return
    reviewed = advance_days(state, days)
    print(f"Fridge date is now {state['date']}.")
    if reviewed:
        print("30-day review ran: usage older than 30 days and one-off foods were cleared.")


MENU = """
FART AI fridge
  1  Add food
  2  Show fridge (ranked by priority)
  3  Take out food
  4  Shopping list
  5  Recurring foods
  6  Settings (preference and nutrition goal)
  7  Advance days (30-day review)
  8  Quit
"""


def main(argv):
    path = argv[1] if len(argv) > 1 else STATE_FILE
    state = load_state(path)
    actions = {"1": add_food, "2": print_inventory, "3": take_out_menu,
               "4": show_shopping, "5": show_recurring, "6": settings_menu,
               "7": advance_menu}
    while True:
        print(MENU)
        choice = ask("Choose 1-8: ")
        if choice == "8" or choice == "":
            save_state(state, path)
            print("Saved. Goodbye.")
            return
        action = actions.get(choice)
        if action is None:
            print("Choose a number from 1 to 8.")
            continue
        action(state)
        save_state(state, path)


if __name__ == "__main__":
    main(sys.argv)
